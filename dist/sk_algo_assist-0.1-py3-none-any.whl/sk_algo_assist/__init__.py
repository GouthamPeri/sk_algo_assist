from sk_algo_assist.algo_assist import compare_algos

def sk_algo_assist():
    return ("An assistant for algorithm selection to help Data Scientists using SKLearn.")